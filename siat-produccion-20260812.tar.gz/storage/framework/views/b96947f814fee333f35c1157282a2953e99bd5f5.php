<script>
<?php if(isset($params['data']['item'])): ?>
    var item = <?php echo $params['data']['item']; ?>;
<?php else: ?>
    var item = null;
<?php endif; ?>
    var siat = {
        filtros: <?= json_encode($params['filtros']) ?>,
        comparadores: <?= json_encode($params['comparadores']) ?>,
        instituciones: <?= json_encode($params['instituciones']) ?>
    }
</script>

<div id="reporte-datos-builder" v-cloak>
    <div class="form-horizontal">
        <div class="form-group">
            <?php echo Form::label('nombre', 'Nombre:', ['class' => 'control-label']); ?>

            <?php echo Form::text('nombre', null, ['v-model' => 'nombre', 'class' => 'form-control', 'autofocus' => 'true', 'placeholder' => 'Nombre del Reporte']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('descripcion', 'Descripcion:', ['class' => 'control-label']); ?>

            <?php echo Form::textarea('descripcion', null, ['v-model' => 'descripcion', 'class' => 'form-control', 'placeholder' => 'Descripción del Reporte']); ?>

        </div>

        <?php if($currentUser->hasRole('sysadmin')): ?>
        <div class="form-group">
            <?php echo Form::label('','Compartir Reporte:', ['class' => 'control-label']); ?>

            <div class="block">
                <div class="checkbox-inline">
                    <label for="activo" class="control-lablel">
                        <?php echo Form::checkbox('activo', '1', null, ['v-model' => 'compartido']); ?> Sí
                    </label>
                </div>
            </div>
        </div>
        <div class="form-group" v-show="compartido">
            <?php echo Form::label('instituciones', 'Instituciones con acceso a este Reporte', ['class' => 'control-label']); ?>

            <div class="row">
                <div class="col-md-12">
                    <ul class="list-group">
                        <li class="list-group-item" v-for="institucion in instituciones" track-by="$index">
                            <a href="#" @click.prevent="borrarInstitucion(institucion)"><i class="fa fa-times-circle fa-fw"></i></a>
                            {{ institucion.nombre }}
                        </li>
                        <li class="list-group-item" v-show="instituciones.length == 0">
                            Todas las instituciones tienen acceso a este Reporte. Si desea restringir el acceso a Instituciones específicas, seleccione las instituciones que pueden ejecutar este reporte abajo.
                        </li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <select name="instituciones" class="form-control" style="width: 100% !important">
                        <?php $__currentLoopData = $params['instituciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field_id => $field_text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($field_id); ?>"><?php echo e($field_text); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <a href="#" class="btn btn-default" @click.prevent="agregarInstitucion()"><i class="fa fa-plus fa-fw"></i>Agregar Institución</a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="form-group">
            <?php echo Form::label('filtros', 'Filtros', ['class' => 'control-label']); ?>

            <div class="row">
                <div class="col-md-12">
                    <ul class="list-group" v-show="filtros && filtros.length > 0">
                        <li class="list-group-item" v-for="filtro in filtros">
                            <a href="#" @click.prevent="borrarFiltro(filtro)"><i class="fa fa-times-circle fa-fw"></i></a>
                            {{ filtro.filtro.nombre }} <em>{{ filtro.comparador.nombre }}</em> <strong>{{ filtro.valor }}</strong>
                        </li>
                    </ul>
                    <div class="alert alert-info" v-show="filtros && filtros.length == 0">No se definieron aún filtros para este reporte.</div>
                </div>
                <div class="col-md-3">
                    <select name="filtros" class="select2" v-model="filtro.campo">
                        <?php $__currentLoopData = $params['filtros']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field_id => $field_text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($field_id); ?>"><?php echo e($field_text); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="comparadores" class="form-control" v-model="filtro.comparador">
                        <option v-for="comparador in comparadoresDisponibles" value="{{ comparador.value }}">{{ comparador.label }}</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <?php echo Form::text('valores', null, ['class' => 'form-control', 'placeholder' => 'Valor', 'v-model' => 'filtro.valor']); ?>

                </div>
                <div class="col-md-3">
                    <a href="#" class="btn btn-default" @click.prevent="agregarFiltro()"><i class="fa fa-filter fa-fw"></i>Agregar Filtro</a>
                </div>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('campos', 'Campos', ['class' => 'control-label']); ?>

            <div class="row">
                <div class="col-md-12">
                    <ul class="list-group" v-show="campos.length > 0">
                        <li class="list-group-item" v-for="campo in campos">
                            <a href="#" @click.prevent="borrarCampo(campo)"><i class="fa fa-times-circle fa-fw"></i></a>
                            {{ campo.nombre }}
                        </li>
                    </ul>
                    <div class="alert alert-info" v-show="campos.length == 0">No se definieron aún campos.</div>
                </div>
                <div class="col-md-8">
                    <select name="campos" class="select2" style="width: 100% !important">
                        <?php $__currentLoopData = $params['campos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field_id => $field_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($field_id); ?>"><?php echo e($field_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <a href="#" class="btn btn-default" @click.prevent="agregarCampo()"><i class="fa fa-plus fa-fw"></i>Agregar Campo</a>
                </div>
            </div>
        </div>

        <div class="form-group">
            <div class="radio">
                <label>
                    <?php echo Form::checkbox('agrupar_campos', 1, null, ['v-model' => 'agrupar_campos']); ?> Agrupar datos usando los campos seleccionados
                </label>
            </div>
        </div>
    </div>
</div>

<div class="panel-footer">
    <div class="row">
        <div class="pull-right">
            <a href="<?php echo e(url($params['route'])); ?>" class="btn btn-default">Cancelar</a>
            <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

        </div>
    </div>
</div>

<?php $__env->startSection('header-css'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('header-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/sweet-alert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-javascript'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer-javascript'); ?>
    <script src="<?php echo e(asset('js/underscore-min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweet-alert.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/reporte-datos-builder.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php /**PATH /var/www/siat.antsv.gov.py/resources/views//reporte_datos/_form.blade.php ENDPATH**/ ?>