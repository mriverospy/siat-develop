<?php $__env->startSection('page-title', 'Iniciar sesión'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" id="login-form">
    <a href="<?php echo e(url('/')); ?>" class="login-logo"><img src="<?php echo e(url($logo_login)); ?>"></a>
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h2>Iniciar sesión</h2>
                </div>
                <div class="panel-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <strong>Tenemos un problema...</strong><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form class="form-horizontal" role="form" method="POST" id="validate-form" action="<?php echo e(url('/login')); ?>">
                        <div><input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"></div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-user"></i>
                                    </span>
                                    <input type="text" class="form-control" name="credencial" placeholder="Nombre de Usuario" value="<?php echo e(old('credencial')); ?>" data-parsley-minlength="3" placeholder="At least 3 characters" autofocus required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-lock"></i>
                                    </span>
                                    <input type="password" class="form-control" name="password" placeholder="Contraseña">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <a href="<?php echo e(url('/password/reset')); ?>" class="pull-left">Recuperar mi contraseña</a>
                                <div class="checkbox-inline icheck pull-right pt0">
                                    <label for="">
                                        <input type="checkbox" name="remember">
                                        Recordarme
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            <div class="clearfix">
                                <button type="submit" class="btn btn-primary pull-right">Iniciar Sesión</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/auth/login.blade.php ENDPATH**/ ?>