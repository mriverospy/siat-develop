<div class="form-horizontal">
    <div class="form-group">
        <?php echo Form::label('name', 'Nombre:', ['class'=>'control-label']); ?>

        <?php echo Form::text('name', null, ['class'=>'form-control', 'placeholder'=>'Nombre del Rol', 'autofocus'=>'true']); ?>


        <?php echo Form::label('display_name', 'Nombre para mostrar:', ['class'=>'control-label']); ?>

        <?php echo Form::text('display_name', null, ['class'=>'form-control', 'placeholder'=>'Nombre  para mostrar']); ?>


        <?php echo Form::label('description', 'Descripción:', ['class'=>'control-label']); ?>

        <?php echo Form::textarea('description', null, ['class'=>'form-control', 'placeholder'=>'Descripción del Rol']); ?>

    </div>
</div>

<div class="panel-footer">
    <div class="row">
        <div class="pull-right">
            <a href = "<?php echo e(url($params['route'])); ?>" class = 'btn btn-default'>Cancelar</a>
            <?php echo Form::submit('Guardar', ['class'=>'btn btn-primary']); ?>

        </div>
    </div>
</div>
<?php /**PATH /var/www/siat.antsv.gov.py/resources/views//roles/_form.blade.php ENDPATH**/ ?>