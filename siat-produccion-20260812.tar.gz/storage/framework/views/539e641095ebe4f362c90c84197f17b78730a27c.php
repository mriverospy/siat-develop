<?php $__env->startSection('page_filters'); ?>
    <form action="" method="GET" accept-charset="UTP-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2>FILTRAR DATOS</h2>
                <div class="panel-ctrls">
                    <div class="pull-right">
                        <button type="submit" class="btn btn-primary">Filtrar</button>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                    <div class="form-inline row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo Form::text('fecha_inicio', $params['current_filters']['fecha_inicio'], ['class' => 'form-control datepicker', 'placeholder' => 'Fecha Inicio']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::text('fecha_fin', $params['current_filters']['fecha_fin'], ['class' => 'form-control datepicker', 'placeholder' => 'Fecha Fin']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::select('objeto', $params['data']['objetos'], $params['current_filters']['objeto'], ['class' => 'form-control', 'placeholder' => 'Objeto']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::select('usuario', $params['data']['usuarios'], $params['current_filters']['usuario'], ['class' => 'form-control', 'placeholder' => 'Usuario']); ?>

                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table_items'); ?>
    <thead>
        <tr>
            <th class="text-center">ID Objeto</th>
            <th class="text-center">Objeto</th>
            <th>Usuario</th>
            <th class="text-center">Acción</th>
            <th class="text-center">Campo</th>
            <th>Fecha Acción</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($item->revisionable_id); ?></td>
            <td class="text-center"><?php echo e(str_replace('App\\Models\\', '', $item->revisionable_type)); ?></td>
            <td>
                <?php if($item->usuario): ?>
                <?php echo e($item->usuario->nombres); ?> <?php echo e($item->usuario->apellidos); ?>

                <?php endif; ?>
            </td>
            <?php if($item->key == 'created_at'): ?>
            <td class="text-center" colspan="2">Creación</td>
            <td><?php echo e($item->created_at); ?></td>
            <?php else: ?>
            <td class="text-center">Modificación</td>
            <td class="text-center"><?php echo e($item->key); ?></td>
            <td><?php echo e($item->created_at); ?></td>
            <?php endif; ?>
        </tr>
        <?php if($item->key != 'created_at'): ?>
        <tr>
            <td colspan="6">
                <div class="row">
                    <div class="col-md-6">
                        <h5>Valor Anterior</h5>
                        <?php echo e($item->old_value); ?>

                    </div>
                    <div class="col-md-6">
                        <h5>Nuevo Valor</h5>
                        <?php echo e($item->new_value); ?>

                    </div>
                </div>
            </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($params['data']['items']) == 0): ?>
        <tr>
            <td colspan="6" class="h4 text-center">No se encontró ningún registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination'); ?>
    <?php echo $params['data']['items']->appends(Request::input())->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.list_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/auditoria/index.blade.php ENDPATH**/ ?>