<?php $__env->startSection('page-title', 'Derivaciones'); ?>

<?php $__env->startSection('table_items'); ?>
    <thead>
        <tr>
            <th class="col-md-1 text-center" rowspan="2">ID</th>
            <th rowspan="2">Estado</th>
            <th rowspan="2">Accidente</th>
            <th colspan="3" class="text-center">Destinatario</th>
            <th rowspan="2">Enviado</th>
            <th rowspan="2" class="col-lg-2 col-md-2 col-sm-3 col-xs-2 text-center">Acciones</th>
        </tr>
        <tr>
            <th>Institución</th>
            <th>Sede</th>
            <th>Usuario</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class='text-center' ><?php echo e($item->id); ?></td>
            <td>
                <span class="label <?php echo e(($item->estado == 'recibido') ? 'label-success' : 'label-default'); ?>"><?php echo e(strtoupper($item->estado)); ?></span>
            </td>
            <td><?php echo e($item->accidente->caratula); ?></td>
            <td><?php echo e($item->institucion_receptor->nombre); ?></td>
            <td><?php echo e($item->sede_receptor ? $item->sede_receptor->nombre : 'Abierto'); ?></td>
            <td><?php echo e($item->usuario_receptor ? $item->usuario_receptor->nombres . ' ' . $item->usuario_receptor->apellidos : 'Abierto'); ?></td>
            <td>
                <span data-toggle="tooltip" data-placement="top" title="enviado el <?php echo e($item->fecha_derivacion->timezone('America/Asuncion')->format('d/m/Y')); ?> a las <?php echo e($item->fecha_derivacion->timezone('America/Asuncion')->format('h:i a')); ?>">
                    <?php echo e($item->fecha_derivacion->diffForHumans()); ?>

                </span>
            </td>
            <td class="text-center">
                <?php if(Auth::user()->ability('sysadmin', 'accidentes-send') AND $item->estado == 'pendiente'): ?>
                    <span data-toggle="tooltip" data-placement="top" title="Cancelar esta Derivación">
                        <a data-toggle="modal" data-target="#modalWindow" class="btn btn-danger btn-sm" data-id="<?php echo e($item->id); ?>"><i class="fa fa-times"></i></a>
                    </span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($params['data']['items']) == 0): ?>
            <tr><td colspan="8" class="h4 text-center">No se encontró ningún registro</td></tr>
        <?php endif; ?>
    </tbody>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination'); ?>
    <?php echo $params['data']['items']->appends(Request::input())->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('modals'); ?>
    <?php echo $__env->make('layouts.confirm_modal_layout', ['modalTitle' => 'Confirmación', 'modalSize' => 'modal-sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.list_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/derivaciones/sent.blade.php ENDPATH**/ ?>