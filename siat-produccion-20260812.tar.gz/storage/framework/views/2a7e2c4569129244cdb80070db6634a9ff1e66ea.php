<?php $__env->startSection('page-title', 'Recuperar Contraseña'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" id="forgotpassword-form">
    <a href="<?php echo e(url('/')); ?>" class="login-logo"><img src="<?php echo e(url($logo_login)); ?>"></a>
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h2>Recuperar Contraseña</h2>
                </div>
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Tenemos un problema...</strong> <br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/password/email')); ?>">
                        <div><input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"></div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <p>Ingresa tu dirección de correo electrónico para recuperar tu contraseña. Enviaremos un mensaje, a la dirección que especifiques, con un enlace.<br />Para cambiar tu contraseña, haz click en el enlace e introduce tu nueva contraseña.</p>
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-envelope"></i>
                                    </span>
                                    <input type="email" class="form-control" placeholder="Correo electrónico" name="email" value="<?php echo e(old('email')); ?>">
                                </div>
                            </div>
                        </div>


                        <div class="panel-footer">
                            <div class="clearfix">
                                <a href="<?php echo e(url('/')); ?>" class="btn btn-default pull-left">Volver</a>
                                <button type="submit" class="btn btn-primary pull-right">Recuperar Contraseña</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>