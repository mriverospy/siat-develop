<?php $__env->startSection('page-title', 'Accidentes'); ?>

<?php $__env->startSection('title_options'); ?>
    <a href="<?php echo e(route('accidentes.index', ['estado' => 'abierto'])); ?>" class="btn btn-default <?php echo e($params['estado'] == 'abierto' ? 'active' : ''); ?>"><i class="fa fa-fw fa-folder-open"></i>Accidentes Abiertos</a>
    <a href="<?php echo e(route('accidentes.index', ['estado' => 'cerrado'])); ?>" class="btn btn-default <?php echo e($params['estado'] == 'cerrado' ? 'active' : ''); ?>"><i class="fa fa-fw fa-folder"></i>Accidentes Cerrados</a>
    <a href="<?php echo e(route('accidentes.bajar-formulario-unico')); ?>" class="btn btn-inverse"><i class="fa fa-fw fa-print"></i> Formulario Único en Blanco</a>
    <?php if($currentUser->ability('sysadmin', $params['route_name'] . '-create')): ?>
    <a href="<?php echo e(url($params['route'])); ?>/cargar" class="btn btn-primary"><i class="fa fa-fw fa-plus"></i> Agregar Accidente</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table_items'); ?>
    <thead>
        <tr>
            <th class="text-center">ID</th>
            <th>Carátula/Lugar</th>
            <th class="text-center">Apertura</th>
            <th class="text-center">Cierre</th>
            <th class="text-center">Estado</th>
            <th>Cargado por</th>
            <th class="text-center">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($item->id); ?></td>
                <td>
                    <a href="<?php echo e(url($params['route'], [$item->id])); ?>">
                        <?php echo e($item->caratula); ?>

                    </a>
                    <br />
                    <?php echo implode('<br>', $item->lugar_accidente); ?>

                </td>
                <td class="text-center">
                    <?php echo e($item->fecha_apertura->timezone('America/Asuncion')->format('d/m/Y h:i a')); ?>

                </td>
                <td class="text-center">
                    <?php echo e($item->fecha_cierre->timezone('America/Asuncion')->format('d/m/Y h:i a')); ?>

                </td>
                <td class="text-center">
                    <?php if($item->estado == 'abierto'): ?>
                    <span class="label label-warning">ABIERTO</span>
                    <?php else: ?>
                    <span class="label label-success">CERRADO</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php echo e($item->usuario->nombreCompleto()); ?>

                    <br />
                    Sede: <?php echo e($item->sede->nombre); ?>

                    <br />
                    Institución: <?php echo e($item->institucion->nombre); ?>

                </td>
                <td class="text-center">
                    <div class="btn-group">
                        <?php if($currentUser->ability('sysadmin', $params['route_name'] . '-view')): ?>
                        <a href="<?php echo e(url($params['route'], [$item->id])); ?>" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Ver Datos del Accidente"><i class="fa fa-eye"></i></a>
                        <?php endif; ?>

                        <?php if($currentUser->ability('sysadmin', $params['route_name'] . '-send')): ?>
                        <a href="<?php echo e(url($params['route'], [$item->id, 'send'])); ?>" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Derivar este Accidente"><i class="fa fa-level-down"></i></a>
                        <?php endif; ?>

                        <?php if($currentUser->ability('sysadmin', $params['route_name'] . '-send-authorization')): ?>
                        <a href="<?php echo e(url($params['route'], [$item->id, 'authorize'])); ?>" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Autorizar Cambios en este Accidente"><i class="fa fa-unlock-alt"></i></a>
                        <?php endif; ?>

                        <?php if($currentUser->ability('sysadmin', $params['route_name'] . '-pdf-report')): ?>
                        <a href="<?php echo e(url($params['route'], [$item->id, 'pdf'])); ?>" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Bajar Informe del Accidente en PDF"><i class="fa fa-download"></i></a>
                        <?php endif; ?>

                        <!-- Edit -->
                        <?php if($currentUser->ability('sysadmin', $params['route_name'] . '-edit') and $item->estado == 'abierto'): ?>
                            <a href="<?php echo e(url($params['route'], [$item->id, 'editar'])); ?>" class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="top" title="Editar este Accidente"><i class="fa fa-pencil"></i></a>
                        <?php endif; ?>

                        <!-- Delete -->
                        <?php if($currentUser->ability('sysadmin', $params['route_name'] . '-delete')): ?>
                        <a data-toggle="modal" data-target="#modalWindow" class="btn btn-danger btn-sm" data-id="<?php echo e($item->id); ?>" ><i class="fa fa-times" data-toggle="tooltip" data-placement="top" title="Borrar este Accidente"></i></a>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($params['data']['items']) == 0): ?>
        <tr>
            <td colspan="6" class="text-center">No se encontró ningún registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination'); ?>
    <?php echo $params['data']['items']->appends(Request::input())->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('modals'); ?>
    <?php echo $__env->make('layouts.confirm_modal_layout', ['modalTitle' => 'Confirmación', 'modalSize' => 'modal-sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.list_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/accidentes/index.blade.php ENDPATH**/ ?>