<?php $__env->startSection('page-title', 'Autorizaciones Enviadas'); ?>

<?php $__env->startSection('table_items'); ?>
    <thead>
        <tr>
            <th class="col-md-1 text-center">ID</th>
            <th>Accidente</th>
            <th>Autorizado a</th>
            <th class="text-center">Fecha</th>
            <th>Otorgado a</th>
            <th class="text-center">Desde</th>
            <th class="text-center">Hasta</th>
            <th class="col-lg-2 col-md-2 col-sm-3 col-xs-2 text-center">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($item->id); ?></td>
            <td><?php echo e($item->accidente->caratula); ?></td>
            <td>
                <?php echo e($item->usuario_receptor->nombres); ?> <?php echo e($item->usuario_receptor->apellidos); ?>

                <br />
                <?php echo e($item->usuario_receptor->sede->institucion->nombre); ?> / <?php echo e($item->usuario_receptor->sede->nombre); ?>

            </td>
            <td class="text-center"><?php echo e($item->fecha_autorizacion->timezone('America/Asuncion')->format('d/m/Y')); ?></td>
            <td><?php echo e($item->usuario_receptor->nombres); ?> <?php echo e($item->usuario_receptor->apellidos); ?></td>
            <td class="text-center"><?php echo e($item->fecha_inicio_autorizacion->timezone('America/Asuncion')->format('d/m/Y')); ?></td>
            <td class="text-center"><?php echo e($item->fecha_fin_autorizacion->timezone('America/Asuncion')->format('d/m/Y')); ?></td>
            <td class="text-center">
                <?php if(Auth::user()->ability('sysadmin', 'accidentes-send-authorization')): ?>
                    <span data-toggle="tooltip" data-placement="top" title="Cancelar esta Autorización">
                        <a data-toggle="modal" data-target="#modalWindow" class="btn btn-danger btn-sm" data-id="<?php echo e($item->id); ?>"><i class="fa fa-times"></i></a>
                    </span>
                <?php endif; ?>
            </td>
        </tr>
        <?php if(trim($item->descripcion) != ''): ?>
        <tr>
            <td colspan="8" class="text-left">
                Descripción: <?php echo e($item->descripcion); ?>

            </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($params['data']['items']) == 0): ?>
            <tr><td colspan="8" class="h4 text-center">No se encontró ningún registro</td></tr>
        <?php endif; ?>
    </tbody>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination'); ?>
    <?php echo $params['data']['items']->appends(Request::input())->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('modals'); ?>
    <?php echo $__env->make('layouts.confirm_modal_layout', ['modalTitle' => 'Confirmación', 'modalSize' => 'modal-sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.list_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/autorizaciones/sent.blade.php ENDPATH**/ ?>