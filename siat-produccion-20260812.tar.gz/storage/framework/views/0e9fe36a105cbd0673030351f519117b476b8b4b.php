<div class="form-horizontal">
    <div class="form-group">
        <div class="row">
            <div class="col-xs-12 col-md-6">
                <?php echo Form::label('nombres', 'Nombres:', ['class' => 'control-label']); ?>

                <?php echo Form::text('nombres', null, ['class' => 'form-control', 'placeholder' => 'Nombres']); ?>

            </div>
            <div class="col-xs-12 col-md-6">
                <?php echo Form::label('apellidos', 'Apellidos:', ['class' => 'control-label']); ?>

                <?php echo Form::text('apellidos', null, ['class' => 'form-control', 'placeholder' => 'Apellidos']); ?>

            </div>

            <div class="col-xs-12 col-md-6">
                <?php echo Form::label('sede_id', 'Sede:', ['class' => 'control-label']); ?>

                <br />
                <?php echo Form::select('sede_id', $params['data']['patern_list'], null, ['class' => 'select2', 'autofocus' => 'true', 'style' => 'width: 100%'] ); ?>

            </div>
            <div class="col-xs-12 col-md-3">
                <?php echo Form::label('documento', 'Nro. Documento:', ['class' => 'control-label']); ?>

                <?php echo Form::text('documento', null, ['class' => 'form-control', 'placeholder' => 'Número de Cedula']); ?>

            </div>
            <div class="col-xs-12 col-md-3">
                <?php echo Form::label('genero', 'Genero:', ['class'=>'control-label']); ?>

                <?php echo Form::select('genero', ['' => 'Seleccione...', 'Masculino' => 'Masculino', 'Femenino' => 'Femenino'], null, ['class' => 'form-control'] ); ?>

            </div>

            <div class="col-xs-12 col-md-7">
                <?php echo Form::label('direccion', 'Dirección:', ['class' => 'control-label']); ?>

                <?php echo Form::text('direccion', null, ['class' => 'form-control', 'placeholder' => 'Dirección']); ?>

            </div>
            <div class="col-xs-12 col-md-5">
                <?php echo Form::label('telefonos', 'Teléfonos:', ['class' => 'control-label']); ?>

                <?php echo Form::text('telefonos', null, ['class' => 'form-control', 'placeholder' => 'Número de Teléfono']); ?>

            </div>
            <div class="col-xs-12">&nbsp;</div>
        </div>

        <p class="h4 text-info">Credenciales del Usuario</p>
        <div class="alert alert-dismissable alert-info">
            <div class="row">
                <div class="col-xs-12 col-md-4 col-lg-4">
                    <?php echo Form::label('rol_id', 'Rol de Usuario:', ['class' => 'control-label']); ?>

                    <?php if(isset($params['data']['item'])): ?>
                    <?php echo Form::select('rol_id', $params['data']['rol_list'], $params['data']['current_rol'], ['class'=>'form-control'] ); ?>

                    <?php else: ?>
                    <?php echo Form::select('rol_id', $params['data']['rol_list'], null, ['class' => 'form-control'] ); ?>

                    <?php endif; ?>
                </div>
                <div class="col-xs-12 col-md-4 col-lg-4">
                    <?php echo Form::label('email', 'E-Mail:', ['class' => 'control-label']); ?>

                    <?php echo Form::text('email', null, ['class' => 'form-control', 'placeholder' => 'Dirección de E-Mail']); ?>

                </div>
                <div class="col-xs-12 col-md-2 col-lg-2">
                    <?php echo Form::label('username', 'Nombre de Usuario:', ['class' => 'control-label']); ?>

                    <?php echo Form::text('username', null, ['class' => 'form-control', 'placeholder' => 'Nombre de Usuario']); ?>

                </div>
                <?php if(!isset($params['data']['item'])): ?>
                    <div class="col-xs-12 col-md-2 col-lg-2">
                        <?php echo Form::label('password', 'Contraseña:', ['class' => 'control-label']); ?>

                        <?php echo Form::password('password', ['class' => 'form-control', 'placeholder' => 'Primera contraseña del usuario']); ?>

                    </div>
                <?php endif; ?>
                <?php if(isset($params['data']['item'])): ?>
                    <div class="col-xs-12 col-md-2 col-lg-2">
                        <?php echo Form::label('','Estado:', ['class' => 'control-label']); ?>

                        <div class="block">
                            <div class="checkbox-inline"><label for="activo" class="control-lablel"><?php echo Form::checkbox('activo','yes',null); ?>Usuario Activo</label></div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="panel-footer">
    <div class="row">
        <?php if(isset($params['data']['item'])): ?>
            <div class="pull-left">
                <a data-toggle="modal" data-target="#modalWindow" class="btn btn-warning" data-id="<?php echo e($params['data']['item']['id']); ?>">Cambiar Contraseña</a>
            </div>
        <?php endif; ?>
        <div class="pull-right">
            <a href = "<?php echo e(url($params['route'])); ?>" class = 'btn btn-default'>Cancelar</a>
            <?php echo Form::submit('Guardar', ['class'=>'btn btn-primary']); ?>

        </div>
    </div>
</div>
<?php /**PATH /var/www/siat.antsv.gov.py/resources/views//usuarios/_form.blade.php ENDPATH**/ ?>