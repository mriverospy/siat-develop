<?php $__env->startSection('layout_content'); ?>
    <div class="panel <?php echo e($params['panel_color']); ?>">
        <div class="panel-heading">
            <h2><?php echo e($params['subtitle']); ?></h2>
        </div>
        <div class="panel-body">
            <?php echo Form::model($params['data']['item'], ['method' => 'PATCH', 'route' => 'user.profile.update', 'files' => (isset($params['files']) ? $params['files'] : false)]); ?>

            <div class="form-horizontal">
                <div class="form-group">
                    <div class="row">
                        <div class="col-xs-12 col-md-6">
                            <?php echo Form::label('nombres', 'Nombres:', ['class' => 'control-label']); ?>

                            <?php echo Form::text('nombres', null, ['class' => 'form-control', 'placeholder' => 'Nombres']); ?>

                        </div>

                        <div class="col-xs-12 col-md-6">
                            <?php echo Form::label('apellidos', 'Apellidos:', ['class' => 'control-label']); ?>

                            <?php echo Form::text('apellidos', null, ['class' => 'form-control', 'placeholder' => 'Apellidos']); ?>

                        </div>

                        <div class="col-xs-12 col-md-4">
                            <?php echo Form::label('email', 'Correo Electrónico:', ['class' => 'control-label']); ?>

                            <?php echo Form::text('email', null, ['class' => 'form-control', 'placeholder' => 'Correo Electrónico']); ?>

                        </div>

                        <div class="col-xs-12 col-md-4">
                            <?php echo Form::label('documento', 'Nro. Documento:', ['class' => 'control-label']); ?>

                            <?php echo Form::text('documento', null, ['class' => 'form-control', 'placeholder' => 'Número de Cedula']); ?>

                        </div>

                        <div class="col-xs-12 col-md-4">
                            <?php echo Form::label('genero', 'Genero:', ['class'=>'control-label']); ?>

                            <?php echo Form::select('genero', ['' => 'Seleccione...', 'Masculino' => 'Masculino', 'Femenino' => 'Femenino'], null, ['class' => 'form-control'] ); ?>

                        </div>

                        <div class="col-xs-12 col-md-7">
                            <?php echo Form::label('direccion', 'Dirección:', ['class' => 'control-label']); ?>

                            <?php echo Form::text('direccion', null, ['class' => 'form-control', 'placeholder' => 'Dirección']); ?>

                        </div>

                        <div class="col-xs-12 col-md-5">
                            <?php echo Form::label('telefonos', 'Teléfonos:', ['class' => 'control-label']); ?>

                            <?php echo Form::text('telefonos', null, ['class' => 'form-control', 'placeholder' => 'Número de Teléfono']); ?>

                        </div>
                    </div>

                    <p class="h4 text-info">Contraseña</p>

                    <div class="alert alert-info">
                        <div class="row">
                            <p>Para cambiar su contraseña, ingrese la nueva contraseña:</p>
                            <div class="col-xs-12 col-md-4 col-lg-4">
                                <?php echo Form::label('password', 'Contraseña:', ['class' => 'control-label']); ?>

                                <?php echo Form::password('password', ['class' => 'form-control', 'placeholder' => 'Contraseña']); ?>

                            </div>
                            <div class="col-xs-12 col-md-4 col-lg-4">
                                <?php echo Form::label('password_confirmation', 'Confirmar Contraseña:', ['class' => 'control-label']); ?>

                                <?php echo Form::password('password_confirmation', ['class' => 'form-control', 'placeholder' => 'Confirmar Contraseña']); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="panel-footer">
                <div class="row">
                    <div class="pull-right">
                        <a href = "<?php echo e(url($params['route'])); ?>" class = 'btn btn-default'>Cancelar</a>
                        <?php echo Form::submit('Guardar', ['class'=>'btn btn-primary']); ?>

                    </div>
                </div>
            </div>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/usuarios/profile.blade.php ENDPATH**/ ?>