<?php $__env->startSection('page-title', 'Notificaciones'); ?>

<?php $__env->startSection('title_options'); ?>
    <a href="<?php echo e(route('notificaciones.flag-as-read')); ?>" class="btn btn-primary"><i class="fa fa-fw fa-eye"></i> Marcar Todo como Leído</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table_items'); ?>
    <thead>
        <tr>
            <th class="text-center">Fecha</th>
            <th>Asunto</th>
            <th class="text-center">Estado</th>
            <th class="col-lg-2 col-md-2 col-sm-3 col-xs-2 text-center">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($item->fecha->timezone('America/Asuncion')->format('d/m/Y h:i a')); ?></td>
            <td><a href="<?php echo e(route('notificaciones.show', [$item->id])); ?>"><?php echo e($item->asunto); ?></a></td>
            <td class="text-center">
                <?php if($item->leido): ?>
                <span class="label label-default">Leído</span>
                <?php else: ?>
                <span class="label label-primary">No Leído</span>
                <?php endif; ?>
            </td>
            <td class="text-center">
                <a href="<?php echo e(route('notificaciones.show', [$item->id])); ?>" class="btn btn-default btn-xs">Ver Mensaje</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($params['data']['items']) == 0): ?>
        <tr>
            <td colspan="5" class="h4 text-center">No se encontraron notificaciones.</td>
        </tr>
        <?php endif; ?>
    </tbody>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination'); ?>
    <?php echo $params['data']['items']->appends(Request::input())->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.list_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/notificaciones/index.blade.php ENDPATH**/ ?>