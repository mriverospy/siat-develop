<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>Tenemos algunos problemas...</strong><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(Session::has('messages')): ?>
    <?php
        $msg = Session::get('messages');

        if($msg['type'] == 'error') {
            $msg['type'] = 'alert-danger';
        } elseif($msg['type'] == 'success') {
            $msg['type'] = 'alert-success';
        } elseif($msg['type'] == 'warning') {
            $msg['type'] = 'alert-warning';
        } else {
            $msg['type'] = 'alert-info';
        }
    ?>
    <div class="alert <?php echo e($msg['type']); ?>">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($msg['text']); ?></strong><br>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/siat.antsv.gov.py/resources/views/partials/alerts.blade.php ENDPATH**/ ?>