<?php $__env->startSection('header-css'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('header-css'); ?>
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/leaflet@1.3.1/dist/leaflet.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-js'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('header-js'); ?>
    <script type="text/javascript" src="https://unpkg.com/leaflet@1.3.1/dist/leaflet.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('layout_content'); ?>
    <div class="panel <?php echo e($params['panel_color']); ?>">
        <div class="panel-heading">
            <h2><?php echo e($params['subtitle']); ?></h2>
        </div>
        <div class="panel-body">
            <?php if(isset($params['data']['item'] )): ?>
                <!-- EDIT -->
                <?php echo Form::model($params['data']['item'], ['method' => 'PATCH', 'url' => [$params['route'], $params['data']['item']->id], 'files' => (isset($params['files']) ? $params['files'] : false)]); ?>

            <?php else: ?>
                <!-- CREATE -->
                <?php echo Form::open(['url' => $params['route'], 'files' => (isset($params['files']) ? $params['files'] : false)]); ?>

            <?php endif; ?>
                <?php echo $__env->make($params['route'] . '._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-javascript'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer-javascript'); ?>
    <script type="text/javascript" charset="utf-8">
        jQuery(document).ready(function($) {
            if ($('select.select2').size()) {
                $('select.select2').select2({
                    width: '100%',
                    placeholder: 'Seleccione una opción...',
                });
            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/layouts/form_layout.blade.php ENDPATH**/ ?>