<?php $__env->startSection('page-title', 'Grupos por Institución'); ?>

<?php $__env->startSection('title_options'); ?>
    <a href="<?php echo e(url('instituciones')); ?>" class="btn btn-default"><i class="fa fa-arrow-left"></i> Volver</a>
    <?php if(Auth::user()->ability('sysadmin', 'grupos-nest')): ?>
        <a href="<?php echo e(url('instituciones', [$params['data']['institucion']->id, 'agrupar_grupos'])); ?>" class="btn btn-default">
            <i class="fa fa-code-fork fa-fw"></i> Agrupar Grupos
        </a>
    <?php endif; ?>
    <?php if(Auth::user()->hasRole('sysadmin')): ?>
        <?php if(Auth::user()->ability('sysadmin', $params['route_name'].'-create')): ?>
            <a href="<?php echo e(url($params['route'])); ?>/add" class="btn btn-primary"><i class="fa fa-fw fa-plus"></i> Agregar Grupo</a>
        <?php endif; ?>
    <?php endif; ?>
    <?php if(Auth::user()->ability('sysadmin', 'grupos-create')): ?>
        <a href="<?php echo e(url('/grupos/create')); ?>" class="btn btn-primary"><i class="fa fa-fw fa-plus"></i> Nuevo Grupo de Preguntas</a>
    <?php endif; ?>
    <?php if(Auth::user()->ability('sysadmin', $params['route_name'].'-edit')): ?>
        <a href="#" id="saveOrderBtn" class="btn btn-success"><i class="fa fa-fw fa-save"></i> Guardar Orden</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('layout_content'); ?>
    <?php if(count($params['data']['items']) == 0): ?>
        <div class="col-sm-12 h4 text-center">No se encontró ningún grupo de preguntas.</div>
        
    <?php else: ?>
        <!--Número de Orden -->
        <div class="col-sm-1 text-center">
            <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-collapsed"><div class="panel-heading h2"><?php echo e($item->orden); ?></div></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Listado de Grupos de Preguntas -->
        <div class="col-sm-11">
            <div class="row ui-sortable" data-widget-group="group-demo">
                <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel panel-collapsed" data-widget="{'id' : '<?php echo e($item->id); ?>'}" data-grupo-id="<?php echo e($item->id); ?>">
                        <div class="panel-heading">
                            <div class="panel-ctrls button-icon-bg" >
                                <?php if(Auth::user()->ability('sysadmin', $params['route_name'].'-delete')): ?>
                                    <div class="panel-ctrls button-icon-bg" >
                                        <a data-toggle="modal" class="button-icon" data-target="#modalWindow" data-id="<?php echo e($item->grupoDePreguntas->id); ?>"><i class="fa fa-times"></i></a>
                                    </div>
                                <?php endif; ?>
                                <?php if(!Auth::user()->hasRole('sysadmin')): ?>
                                    <?php if($currentUser->ability('sysadmin', 'preguntas-list')): ?>
                                        <a href="<?php echo e(url('/grupos/'.$item->grupoDePreguntas->id.'/preguntas')); ?>" class="button-icon"><i class="fa fa-tasks"></i></a>
                                    <?php endif; ?>
                                    <?php if($currentUser->ability('sysadmin', 'grupos-edit')): ?>
                                        <a href="<?php echo e(url('grupos', [$item->grupoDePreguntas->id, 'edit'])); ?>" class="button-icon"><i class="fa fa-pencil"></i></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <h2>
                                <?php echo e($item->grupoDePreguntas->nombre); ?>

                                <?php if($item->grupoDePreguntas->puede_duplicar): ?>
                                (<i class="fa fa-copy fa-lg"></i> Duplicable)
                                <?php endif; ?>
                            </h2>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('modals'); ?>
    <?php echo $__env->make('layouts.confirm_modal_layout', ['modalTitle' => 'Confirmación', 'modalSize' => 'modal-sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-javascript'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer-javascript'); ?>
    <script>
        $.wijets().make();

        $('#saveOrderBtn').on('click', function (event) {
            var items = [];
            $('.ui-sortable .panel').each(function(index, element) {
                items.push({ id: $(element).data('grupo-id'), orden: index + 1});
            });

            $.ajax({
              url: "save_order",
              type: "POST",
              data: {_token: <?php echo "'".Session::token()."'"; ?>, items: items},
              success: function(data){
                  location.reload();
              }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/grupos_por_institucion/index.blade.php ENDPATH**/ ?>