<?php $__env->startSection('layout_content'); ?>
    <?php echo $__env->yieldContent('page_filters'); ?>

	<div class="panel panel-default">
		<div class="panel-heading">
			<h2><?php echo e($params['subtitle']); ?></h2>
			<div class="panel-ctrls">
				<div class="dataTables_filter pull-right">
				<?php if(isset($params['search']) and $params['search'] == 'YES'): ?>
					<form action="" method="GET" accept-charset="UTP-8">
						<label class="panel-ctrls-center">
							<input type="search" id="bx_filter" name="filter" class="form-control" value="<?php echo e($params['filter']); ?>" placeholder="Buscar...">
						</label>
					</form>
				<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="panel-body panel-no-padding">
			<div id="example_wrapper" class="dataTables_wrapper form-inline no-footer">
				<div class="row">
					<div class="col-sm-6"></div>
					<div class="col-sm-6"></div>
				</div>

				<div class="table-responsive">
					<table class="table table-striped table-bordered dataTable no-footer" cellspacing="0" width="100%" role="grid" aria-describedby="list-table" style="width: 100%;">
	                    <?php echo $__env->yieldContent('table_items'); ?>
					</table>
				</div>
			</div>
		</div>
		<div class="panel-footer">
			<div class="pull-right mr10">
				<?php echo $__env->yieldContent('pagination'); ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-javascript'); ?>
    <script type="text/javascript" charset="utf-8">
        $('document').ready(function(){
            $('#bx_filter').focus();
            $('#bx_filter').select();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/layouts/list_layout.blade.php ENDPATH**/ ?>