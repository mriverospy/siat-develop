<?php $__env->startSection('page-title', 'Datos del Accidente'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1>Datos del Accidente</h1>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 text-right">
            <p>
                <?php if($currentUser->ability('sysadmin', $params['route_name'] . '-pdf')): ?>
                <a href="<?php echo e(url('accidentes/' . $accidente->id . '/pdf')); ?>" class="btn btn-default"><i class="fa fa-fw fa-download"></i>Exportar a PDF</a>
                <?php endif; ?>

                <?php if($currentUser->ability('sysadmin', $params['route_name'] . '-edit') and $accidente->estado == 'abierto'): ?>
                <a href="<?php echo e(url($params['route'], [$accidente->id, 'editar'])); ?>" class="btn btn-primary"><i class="fa fa-fw fa-pencil"></i>Editar</a>
                <?php endif; ?>
            </p>
        </div>
        <div class="col-md-12">
            <div class="panel panel-inverse">
                <div class="panel-heading">
                    <h2>Bloque 24 Horas</h2>

                </div>
                <div class="panel-body">
                    <dl class="dl-horizontal">
                        <dt>Carátula:</dt>
                        <dd><?php echo e($accidente->caratula); ?></dd>
                        <dt>Nro. Expendiente:</dt>
                        <dd><?php echo e($accidente->expediente_judicial); ?></dd>
                        <dt>Nro. Sumario:</dt>
                        <dd><?php echo e($accidente->sumario_policial); ?></dd>
                        <dt>Otro:</dt>
                        <dd><?php echo e($accidente->otro); ?></dd>
                        <dt>Dependencia:</dt>
                        <dd><?php echo e($accidente->dependencia); ?></dd>
                        <dt>Fecha y Hora:</dt>
                        <dd><?php echo e($accidente->fecha_accidente->format('d/m/Y h:i a')); ?></dd>
                        <dt>Lugar:</dt>
                        <dd><?php echo e($accidente->lugar); ?></dd>
                        <dt>Altura:</dt>
                        <dd><?php echo e($accidente->altura); ?></dd>
                        <dt>Tipo Camino:</dt>
                        <dd><?php echo e(ucwords($accidente->tipo_camino)); ?></dd>
                        <dt>Localidad:</dt>
                        <dd><?php echo e($accidente->localidad->nombre); ?></dd>
                        <dt>Distrito:</dt>
                        <dd><?php echo e($accidente->localidad->distrito->nombre); ?></dd>
                        <dt>Departamento:</dt>
                        <dd><?php echo e($accidente->localidad->distrito->departamento->nombre); ?></dd>
                        <dt>Codigo Postal:</dt>
                        <dd><?php echo e($accidente->codigo_postal); ?></dd>
                        <dt>Heridos:</dt>
                        <dd><?php echo e($accidente->heridos); ?></dd>
                        <dt>Fallecidos:</dt>
                        <dd><?php echo e($accidente->fallecidos); ?></dd>
                        <dt>Ilesos:</dt>
                        <dd><?php echo e($accidente->ilesos); ?></dd>
                        <dt>Participantes:</dt>
                        <dd><?php echo e($accidente->participantes_siniestro); ?></dd>
                    </dl>
                </div>
            </div>
        </div>

        <?php if(count($respuestas) > 0): ?>
        <div class="col-md-12">
            <?php $__currentLoopData = $respuestas->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h2><?php echo e($grupo['grupo']); ?></h2>
                        </div>
                        <div class="panel-body">
                            <?php $__currentLoopData = $grupo['respuestas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden => $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <dl>
                                <?php $__currentLoopData = $pregunta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre => $respuestas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <dt>
                                    <?php echo e($nombre); ?>

                                </dt>
                                <dd>
                                    <ul class="list-group">
                                    <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                        <?php if(in_array($respuesta->pregunta_tipo, array('radio', 'check', 'text'))): ?>
                                            <?php echo e($respuesta->respuesta_texto); ?>

                                        <?php endif; ?>
                                        <?php if($respuesta->pregunta_tipo == 'number'): ?>
                                            <?php echo e($respuesta->respuesta_numero); ?>

                                        <?php endif; ?>
                                        <?php if($respuesta->pregunta_tipo == 'date'): ?>
                                            <?php echo e($respuesta->respuesta_fecha->format('d/m/Y')); ?>

                                        <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </dd>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </dl>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/accidentes/show.blade.php ENDPATH**/ ?>