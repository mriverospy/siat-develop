<?php echo e($slot); ?>

<?php /**PATH /var/www/siat.antsv.gov.py/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>