<header id="topnav" class="navbar navbar-inverse navbar-fixed-top clearfix" role="banner">
    <a id="leftmenu-trigger" class="" data-toggle="tooltip" data-placement="right" title="Ver/Ocultar Barra Lateral"></a>
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>" style="background-image: url(<?php echo e(url($logo_cabecera)); ?>)"></a>
    <?php if(Auth::guest()): ?>
    <?php else: ?>
    <ul class="nav navbar-nav toolbar pull-right">
        <?php if($notificaciones_no_leidas > 0): ?>
        <li class="dropdown toolbar-icon-bg">
            <a href="#" class="hasnotifications dropdown-toggle" data-toggle="dropdown">
                <span class="icon-bg"><i class="fa fa-fw fa-bell"></i></span>
                <span class="badge badge-primary"><?php echo e($notificaciones_no_leidas); ?></span>
            </a>
            <div class="dropdown-menu notifications arrow">
                <div class="dd-header">
                    <span>Notificaciones</span>
                    <!-- <span><a href="#">Configuración</a></span> -->
                </div>
                <ul class="scrollthis">
                    <?php $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('notificaciones.show', [$item->id])); ?>" class="notification-inverse">
                            <div class="notification-icon"><i class="fa fa-envelope fa-fw"></i></div>
                            <div class="notification-content"><?php echo e($item->asunto); ?></div>
                            <div class="notification-time"><?php echo e($item->fecha->timezone('America/Asuncion')->diffForHumans()); ?></div>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="dd-footer">
                    <a href="<?php echo e(route('notificaciones.index')); ?>">Ver todas las notificaciones</a>
                </div>
            </div>
        </li>
        <?php else: ?>
        <li>
            <a href="<?php echo e(route('notificaciones.index')); ?>">
                <span class="icon-bg"><i class="fa fa-fw fa-bell"></i></span>
            </a>
        </li>
        <?php endif; ?>
        <li class="dropdown">
            <a href="#" class="dropdown-toggle username" data-toggle="dropdown">
                <span class="hidden-xs"><i class="fa fa-fw fa-institution"></i> <?php echo e($currentUser->sede->institucion->nombre); ?>/<?php echo e($currentUser->sede->nombre); ?> <i class="fa fa-fw fa-user"></i> <?php echo e($currentUser->nombreCompleto()); ?></span>
            </a>
            <ul class="dropdown-menu userinfo">
                <li>
                    <a href="<?php echo e(route('user.profile')); ?>">
                        <span class="pull-left">Editar Perfil</span> <i class="pull-right fa fa-pencil"></i>
                    </a>
                </li>
                <li class="divider"></li>
                <li>
                    <a href="<?php echo e(url('logout')); ?>">
                        <span class="pull-left">Cerrar sesión</span> <i class="pull-right fa fa-sign-out"></i>
                    </a>
                </li>
            </ul>
        </li>
    </ul>
    <?php endif; ?>
</header>
<?php /**PATH /var/www/siat.antsv.gov.py/resources/views/partials/header.blade.php ENDPATH**/ ?>