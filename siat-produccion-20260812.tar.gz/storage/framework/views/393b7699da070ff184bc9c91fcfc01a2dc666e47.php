<?php $__env->startSection('page-title', $params['subtitle']); ?>

<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1><?php echo $params['title']; ?></h1>
    <div class="options">
        <div class="btn-toolbar">
            <?php echo $__env->yieldContent('title_options'); ?>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('layout_content'); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/layouts/base_layout.blade.php ENDPATH**/ ?>