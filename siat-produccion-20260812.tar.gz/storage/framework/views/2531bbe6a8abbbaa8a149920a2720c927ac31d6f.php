[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /var/www/siat.antsv.gov.py/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>