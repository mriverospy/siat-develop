<?php $__env->startSection('title_options'); ?>
    <form action="<?php echo e(url($params['route'], [$reporte->id])); ?>" method="get">
        <?php if(Auth::user()->ability('sysadmin', $params['route_name'].'-list')): ?>
            <a href="<?php echo e(url($params['route'])); ?>" class="btn btn-default"><i class="fa fa-arrow-left fa-fw"></i> Atrás</a>
        <?php endif; ?>
        <button type="button" id="reporte-rango-fechas" class="btn btn-default">
            <i class="fa fa-calendar"></i>
            <span><?php echo date('d-m-Y', strtotime('-30 day')); ?> &mdash; <?php echo date('d-m-Y'); ?></span> <b class="caret"></b>
        </button>
        <input type="hidden" name="fecha_inicio" value="" />
        <input type="hidden" name="fecha_fin" value="" />
        <button class="btn btn-primary" type="submit"><i class="fa fa-bolt"></i> Ejecutar</button>
        <?php if(Auth::user()->ability('sysadmin', $params['route_name'].'-list')): ?>
            <a href="<?php echo e(url($params['route'], [$reporte->id, 'edit'])); ?>" class="btn btn-default"><i class="fa fa-pencil fa-fw"></i> Editar</a>
        <?php endif; ?>
        <?php if($fecha_inicio): ?>
        <a href="<?php echo e(route('reporte_datos.csv', [$reporte->id, 'fecha_inicio' => $fecha_inicio, 'fecha_fin' => $fecha_fin])); ?>" class="btn btn-default"><i class="fa fa-file-o fa-fw"></i> Exportar a CSV</a>
        <a href="<?php echo e(route('reporte_datos.pdf', [$reporte->id, 'fecha_inicio' => $fecha_inicio, 'fecha_fin' => $fecha_fin])); ?>" class="btn btn-default"><i class="fa fa-file-pdf-o fa-fw"></i> Exportar a PDF</a>
        <?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table_items'); ?>
    <thead>
        <tr>
            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column_key => $column_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th class="text-center"><?php echo e($column_name); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $reporteDatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column_key => $column_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td class="<?php echo e((stristr($column_key, 'total') !== FALSE) ? 'text-right' : ''); ?>"><?php echo e($item->$column_key); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($reporteDatos->count() == 0): ?>
        <tr><td colspan="<?php echo e(count($columns)); ?>" class="h4 text-center">No se encontró ningún registro</td></tr>
        <?php endif; ?>
    </tbody>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination'); ?>
    <?php if($reporteDatos->count() > 0): ?>
        <?php echo $reporteDatos->appends(Request::input())->render(); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('modals'); ?>
    <?php echo $__env->make('layouts.confirm_modal_layout', ['modalTitle' => 'Confirmación', 'modalSize' => 'modal-sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-javascript'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer-javascript'); ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#reporte-rango-fechas').daterangepicker({
                ranges: {
                    'Hoy': [moment(), moment()],
                    'Ayer': [moment().subtract('days', 1), moment().subtract('days', 1)],
                    'Últimos 7 días': [moment().subtract('days', 6), moment()],
                    'Últimos 30 días': [moment().subtract('days', 29), moment()],
                    'Este mes': [moment().startOf('month'), moment().endOf('month')],
                    'Mes pasado': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
                },
                opens: 'right',
                <?php if(is_null($fecha_inicio)): ?>
                startDate: moment().subtract('days', 29),
                <?php else: ?>
                startDate: moment('<?php echo e($fecha_inicio); ?>'),
                <?php endif; ?>
                <?php if(is_null($fecha_fin)): ?>
                endDate: moment(),
                <?php else: ?>
                endDate: moment('<?php echo e($fecha_fin); ?>'),
                <?php endif; ?>
                locale: {
                    applyLabel: 'Definir',
                    cancelLabel: 'Cancelar',
                    fromLabel: 'Desde',
                    toLabel: 'Hasta',
                    weekLabel: 'S',
                    customRangeLabel: 'Definir Rango',
                    daysOfWeek: moment()._lang._weekdaysMin.slice(),
                    monthNames: moment()._lang._monthsShort.slice(),
                    firstDay: 0
                }
            }, function(start, end) {
                $('#reporte-rango-fechas span').html(start.format('DD-MM-YYYY') + ' &mdash; ' + end.format('DD-MM-YYYY'));
                $('input[name=fecha_inicio]').val(start.format('YYYY-MM-DD'));
                $('input[name=fecha_fin]').val(end.format('YYYY-MM-DD'));
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.list_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/reporte_datos/show.blade.php ENDPATH**/ ?>