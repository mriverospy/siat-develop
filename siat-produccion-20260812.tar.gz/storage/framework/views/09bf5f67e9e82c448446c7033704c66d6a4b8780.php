<div class="widget stay-on-collapse">
    <div class="widget-body welcome-box tabular">
        <a href="<?php echo e(url('/home')); ?>">
            <img  class="img-responsive"src="<?php echo e(url($logo_principal)); ?>">
        </a>
    </div>
</div>

<div class="widget stay-on-collapse" id="widget-sidebar">
    <span class="widget-heading">Menu</span>
    <nav role="navigation" class="widget-body">
        <?php if(count($mainMenu) > 0): ?>
            <ul class="acc-menu">
            <?php $__currentLoopData = $mainMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (is_array($topMenu['items']) AND count($topMenu['items']) == 0 AND $topMenu['is_home'] == false) continue; ?>
                <li class="<?php echo e((count($topMenu['items']) > 0) ? 'hasChild' : ''); ?> <?php echo e($topMenu['container_classes']); ?>">
                    <a href="<?php echo e($topMenu['url']); ?>">
                        <?php if( ! is_null($topMenu['icon_classes'])): ?>
                        <i class="<?php echo e($topMenu['icon_classes']); ?>"></i>
                        <?php endif; ?>
                        <span><?php echo e($topMenu['title']); ?></span>
                    </a>
                    <?php if(count($topMenu['items']) > 0): ?>
                    <ul class="acc-menu">
                        <?php $__currentLoopData = $topMenu['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e($menu['url']); ?>">
                                    <?php if( ! is_null($menu['icon_classes'])): ?>
                                    <i class="<?php echo e($menu['icon_classes']); ?>"></i>
                                    <?php endif; ?>
                                    <span><?php echo e($menu['title']); ?></span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </nav>
</div>
<?php /**PATH /var/www/siat.antsv.gov.py/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>