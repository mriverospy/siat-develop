<?php $__env->startSection('modalContent'); ?>
    <div class="modal-body">
        <p>Realmente desea borrar el registro seleccionado?</p>
    </div>
    <div class="modal-footer">
        <?php echo Form::open(['id' => 'delete-form', 'method' => 'DELETE', 'url'=>$params['route'], 'class'=>'form-inline']); ?>

        <?php echo Form::button('Cancelar', ['type' => 'button', 'class' => 'btn btn-default','data-dismiss' => 'modal']); ?>

        <?php echo Form::button('Eliminar Registro', ['type' => 'submit', 'class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-javascript'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer-javascript'); ?>
    <script type="text/javascript" charset="utf-8">
        $('#modalWindow').on('show.bs.modal', function (event) {
            var messageText = $(event.relatedTarget).data('message-text');
            if (messageText) {
                $('#modalWindow').find('div.modal-body').append($('<p class="text-danger">' + messageText + '</p>'));
            }
            else {
                $('#modalWindow').find('div.modal-body').html($('<p>Realmente desea borrar el registro seleccionado?</p>'));
            }
            var id = $(event.relatedTarget).data('id');
            var delRoute = '<?php echo e(url($params['route'])); ?>/' + id;
            $('#delete-form').attr('action', delRoute);
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/layouts/confirm_modal_layout.blade.php ENDPATH**/ ?>