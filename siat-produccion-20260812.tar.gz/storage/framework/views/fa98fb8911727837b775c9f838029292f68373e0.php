<?php $__env->startSection('layout_content'); ?>
    <div class="panel <?php echo e($params['panel_color']); ?>">
        <div class="panel-heading">
            <h2><?php echo e($params['subtitle']); ?></h2>
        </div>

        <div class="panel-body">
            <!-- CREATE -->
            <?php echo Form::open(['route' => 'configuracion.save', 'files' => true]); ?>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('formato_formulario_unico', 'Formato Formulario Único:', ['class' => 'col-sm-2 control-label']); ?>

                        <div class="col-sm-10">
                            <label class="radio-inline icheck">
                                <?php echo Form::radio('formato_formulario_unico', 'expandido', $settings['formato_formulario_unico'] == 'expandido'); ?> Expandido
                            </label>
                            <label class="radio-inline icheck">
                                <?php echo Form::radio('formato_formulario_unico', 'condensado', $settings['formato_formulario_unico'] == 'condensado'); ?> Condensado
                            </label>
                        </div>
                    </div>
                </div>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('dias_edicion', 'Días para Edición', ['class' => 'col-sm-2 control-label']); ?>

                        <div class="col-sm-10">
                            <?php echo Form::text('dias_edicion', $settings['dias_edicion'], ['class' => 'form-control', 'placeholder' => 'Cantidad de Días']); ?>

                            <p class="help-block">Cantidad de Días que un Accidente está disponible para edición, desda la fecha en que fue cargado.</p>
                        </div>
                    </div>
                </div>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('logo_membrete', 'Logo/Membrete:', ['class' => 'col-sm-2 control-label']); ?>

                        <div class="col-sm-10">
                            <?php echo Form::file('logo_membrete', null, ['class' => 'form-control', 'placeholder' => 'Logo Membrete']); ?>

                            <img src="<?php echo e($settings['logo_membrete']); ?>" alt="Logo Membrete" />
                            <p class="help-block">Tamaño recomendado: al menos 1000px x 400px.</p>
                        </div>
                    </div>
                </div>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('logo_login', 'Logo Inicio Sesión:', ['class' => 'col-sm-2 control-label']); ?>

                        <div class="col-sm-10">
                            <?php echo Form::file('logo_login', null, ['class' => 'form-control', 'placeholder' => 'Logo Inicio Sesión']); ?>

                            <img src="<?php echo e($settings['logo_login']); ?>" alt="Logo Inicio Sesión" />
                            <p class="help-block">Tamaño requerido: 310x83 pixels. <a href="<?php echo e(asset('img/login-logo.psd')); ?>">Ver archivo PSD de ejemplo</a>.</p>
                        </div>
                    </div>
                </div>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('logo_principal', 'Logo Principal:', ['class' => 'col-sm-2 control-label']); ?>

                        <div class="col-sm-10">
                            <?php echo Form::file('logo_principal', null, ['class' => 'form-control', 'placeholder' => 'Logo Principal']); ?>

                            <img src="<?php echo e($settings['logo_principal']); ?>" alt="Logo Principal" />
                            <p class="help-block">Tamaño requerido: 310x83 pixels. <a href="<?php echo e(asset('img/login-logo.psd')); ?>">Ver archivo PSD de ejemplo</a>.</p>
                        </div>
                    </div>
                </div>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('logo_cabecera', 'Logo/Membrete:', ['class' => 'col-sm-2 control-label']); ?>

                        <div class="col-sm-10">
                            <?php echo Form::file('logo_cabecera', null, ['class' => 'form-control', 'placeholder' => 'Logo Membrete']); ?>

                            <img src="<?php echo e($settings['logo_cabecera']); ?>" alt="Logo Membrete" />
                            <p class="help-block">Tamaño requerido: 140x100 pixels. <a href="<?php echo e(asset('img/avalon-logo.psd')); ?>">Ver archivo PSD de ejemplo</a>.</p>
                        </div>
                    </div>
                </div>

                <div class="panel-footer">
                    <div class="row">
                        <div class="pull-right">
                            <a href = "<?php echo e(url($params['route'])); ?>" class="btn btn-default">Cancelar</a>
                            <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

                        </div>
                    </div>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/configuracion/show.blade.php ENDPATH**/ ?>