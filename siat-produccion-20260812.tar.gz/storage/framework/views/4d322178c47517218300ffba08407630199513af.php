<?php $__env->startSection('title_options'); ?>
    <?php if(Auth::user()->ability('sysadmin', $params['route_name'].'-create')): ?>
        <a href="<?php echo e(url($params['route'])); ?>/create" class="btn btn-primary"><i class="fa fa-fw fa-plus"></i> Agregar</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table_items'); ?>
    <thead>
        <tr>
            <th class="col-md-1 text-center">ID</th>
            <th>Nombre</th>
            <th class="col-lg-2 col-md-2 col-sm-3 col-xs-2 text-center">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($item->id); ?></td>
            <td>
                <?php echo e($item->nombre); ?>

                <?php if($item->compartido): ?>
                    <small class="text-success"><i class="fa fa-star fa-fw"></i>Compartido</small>
                <?php endif; ?>
            </td>
            <td class="text-center">
                <?php if(Auth::user()->ability('sysadmin', $params['route_name'] . '-list')): ?>
                    <a href="<?php echo e(url($params['route'], [$item->id])); ?>" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="Ejecutar este Reporte"><i class="fa fa-bolt"></i></a>
                <?php endif; ?>
                <?php if($item->compartido == false OR $item->usuario_id == Auth::user()->id): ?>
                    <?php if(Auth::user()->ability('sysadmin', $params['route_name'] . '-edit')): ?>
                        <a href="<?php echo e(url($params['route'], [$item->id, 'edit'])); ?>" class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="top" title="Editar este Reporte"><i class="fa fa-pencil"></i></a>
                    <?php endif; ?>
                    <?php if(Auth::user()->ability('sysadmin', $params['route_name'] . '-delete')): ?>
                        <span data-toggle="tooltip" data-placement="top" title="Borrar este Reporte">
                            <a data-toggle="modal" data-target="#modalWindow" class="btn btn-danger btn-sm" data-id="<?php echo e($item->id); ?>"><i class="fa fa-times"></i></a>
                        </span>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($params['data']['items']) == 0): ?>
        <tr><td colspan="4" class="h4 text-center">No se encontró ningún registro</td></tr>
        <?php endif; ?>
    </tbody>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination'); ?>
    <?php echo $params['data']['items']->appends(Request::input())->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('modals'); ?>
    <?php echo $__env->make('layouts.confirm_modal_layout', ['modalTitle' => 'Confirmación', 'modalSize' => 'modal-sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.list_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/reportes/index.blade.php ENDPATH**/ ?>