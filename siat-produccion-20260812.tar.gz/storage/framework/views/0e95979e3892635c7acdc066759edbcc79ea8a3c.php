<?php $__env->startSection('page-title', 'Grupo de Preguntas'); ?>

<?php $__env->startSection('title_options'); ?>
    <?php if($currentUser->ability('sysadmin', $params['route_name'] . '-create')): ?>
        <a href="<?php echo e(url($params['route'])); ?>/create" class="btn btn-primary"><i class="fa fa-fw fa-plus"></i> Agregar</a>
    <?php endif; ?>
    <?php if(Auth::user()->hasRole('sysadmin')): ?>
        <a href="<?php echo e(url($params['route'])); ?>/masters_order" class="btn btn-warning"><i class="fa fa-fw fa-list-ol"></i> Ordenar Masters</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table_items'); ?>
    <thead>
        <tr>
            <th class="text-center">ID</th>
            <th>Nombre</th>
            <th class="text-center">Cantidad Preguntas</th>
            <th class="text-center">Maestro?</th>
            <th class="text-center">Duplicable?</th>
            <th class="text-center">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="<?php echo e($item->total_preguntas == 0 ? 'danger' : ''); ?>">
            <td class="text-center"><?php echo e($item->id); ?></td>
            <td>
                <?php echo e($item->nombre); ?>

                <br>
                <small><?php echo e($item->descripcion); ?></small>
            </td>
            <td class="text-center">
                <?php echo e($item->total_preguntas); ?>

            </td>
            <td class="text-center">
                <?php if($item->master): ?>
                <span class="label label-primary">Sí</span>
                <?php else: ?>
                <span class="label label-default">No</span>
                <?php endif; ?>
            </td>
            <td class="text-center">
                <?php if($item->puede_duplicar): ?>
                <span class="label label-primary">Sí</span>
                <?php else: ?>
                <span class="label label-default">No</span>
                <?php endif; ?>
            </td>
            <td class="text-center">
                <!-- Edit -->
                <?php if($currentUser->ability('sysadmin', $params['route_name'].'-edit')): ?>
                <a href="<?php echo e(url($params['route'], [$item->id, 'edit'])); ?>" class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="top" title="Editar este Grupo de Preguntas"><i class="fa fa-pencil"></i></a>
                <?php endif; ?>
                <!-- Preguntas -->
                <?php if($currentUser->ability('sysadmin', 'preguntas-list')): ?>
                <a href="<?php echo e(url($params['route'], [$item->id, 'preguntas'])); ?>" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="Listar Preguntas en este Grupo de Preguntas"><i class="fa fa-tasks"></i></a>
                <?php endif; ?>
                <!-- Delete -->
                <?php if($currentUser->ability('sysadmin', $params['route_name'].'-delete') AND $item->master === FALSE): ?>
                <span data-toggle="tooltip" data-placement="top" title="Borrar este Grupo de Preguntas">
                    <a data-toggle="modal" data-target="#modalWindow" class="btn btn-danger btn-sm" data-id="<?php echo e($item->id); ?>" data-message-text="Esta acción es **permanente** y se borrarán adicionalmente, todas las preguntas y respuestas asociadas a este Grupo de Preguntas!!!"><i class="fa fa-times"></i></a>
                </span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($params['data']['items']) == 0): ?>
            <tr><td colspan="3" class="h4 text-center">No se encontró ningún registro</td></tr>
        <?php endif; ?>
    </tbody>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination'); ?>
    <?php echo $params['data']['items']->appends(Request::input())->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('modals'); ?>
    <?php echo $__env->make('layouts.confirm_modal_layout', ['modalTitle' => 'Confirmación', 'modalSize' => 'modal-sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.list_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/grupos/index.blade.php ENDPATH**/ ?>