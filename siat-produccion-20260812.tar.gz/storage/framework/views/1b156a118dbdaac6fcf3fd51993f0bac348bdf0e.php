<?php $__env->startSection('page-title', 'Autorizaciones Recibidas'); ?>

<?php $__env->startSection('table_items'); ?>
    <thead>
        <tr>
            <th class="col-md-1 text-center">ID</th>
            <th>Accidente</th>
            <th>Autorizado por</th>
            <th class="text-center">Fecha</th>
            <th>Otorgado a</th>
            <th class="text-center">Desde</th>
            <th class="text-center">Hasta</th>
            <th>Vence</th>
            <th class="text-center">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class='text-center' ><?php echo e($item->id); ?></td>
            <td><?php echo e($item->accidente->caratula); ?></td>
            <td><?php echo e($item->usuario_emisor->nombres); ?> <?php echo e($item->usuario_emisor->apellidos); ?></td>
            <td class="text-center"><?php echo e($item->fecha_autorizacion->timezone('America/Asuncion')->format('d/m/Y')); ?></td>
            <td><?php echo e($item->usuario_receptor->nombres); ?> <?php echo e($item->usuario_receptor->apellidos); ?></td>
            <td class="text-center"><?php echo e($item->fecha_inicio_autorizacion->timezone('America/Asuncion')->format('d/m/Y')); ?></td>
            <td class="text-center"><?php echo e($item->fecha_fin_autorizacion->timezone('America/Asuncion')->format('d/m/Y')); ?></td>
            <td><?php echo e($item->fecha_fin_autorizacion->diffForHumans()); ?></td>
            <td class="text-center">
                <div class="btn-group">
                    <a href="<?php echo e(route('autorizaciones.show', [$item->id])); ?>" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Ver Autorización de Cambios"><i class="fa fa-eye"></i></a>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($params['data']['items']) == 0): ?>
            <tr><td colspan="8" class="h4 text-center">No se encontró ningún registro</td></tr>
        <?php endif; ?>
    </tbody>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination'); ?>
    <?php echo $params['data']['items']->appends(Request::input())->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('modals'); ?>
    <?php echo $__env->make('layouts.confirm_modal_layout', ['modalTitle' => 'Confirmación', 'modalSize' => 'modal-sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.list_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/autorizaciones/received.blade.php ENDPATH**/ ?>