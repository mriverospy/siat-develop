<div class="form-horizontal">
    <div class="form-group">
        <?php echo Form::label('nombre', 'Nombre:', ['class' => 'control-label']); ?>

        <?php echo Form::text('nombre', null, ['class' => 'form-control', 'autofocus' => 'true', 'placeholder' => 'Nombre del Grupo de preguntas']); ?>


        <?php echo Form::label('descripcion', 'Descripcion:', ['class' => 'control-label']); ?>

        <?php echo Form::textarea('descripcion', null, ['class' => 'form-control', 'placeholder' => 'Descripción del Grupo de preguntas']); ?>


        <div class="radio">
            <label>
                <?php echo Form::radio('puede_duplicar', 1, null); ?> Este grupo <strong>se puede duplicar</strong> en la Interfaz de Carga
            </label>
        </div>
        <div class="radio">
            <label>
                <?php echo Form::radio('puede_duplicar', 0, null); ?> Este grupo <strong>no se puede duplicar</strong> en la Interfaz de Carga
            </label>
        </div>
    </div>
</div>

<!-- Tu código JavaScript -->
<script>
document.getElementById('siRadio').addEventListener('click', function() {
    console.log('Seleccionaste "Sí", el valor de obligatorio es ahora 1');
});

document.getElementById('noRadio').addEventListener('click', function() {
    console.log('Seleccionaste "No", el valor de obligatorio es ahora 0');
});
</script>

<div class="panel-footer">
    <div class="row">
        <?php if(isset($params['data']['item'])): ?>
        <div class="pull-left">
            <?php if($params['data']['item']['master']): ?>
            <a href="<?php echo e(url($params['route'], $params['data']['item']['id'])); ?>/unset_master" class="btn btn-success"><i class="fa fa-fw fa-star-o"></i> Restablecer como Grupo Normal</a>
            <?php else: ?>
            <a href="<?php echo e(url($params['route'], $params['data']['item']['id'])); ?>/set_master" class="btn btn-warning"><i class="fa fa-fw fa-star"></i> Establecer como Grupo Master</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <div class="pull-right">
            <a href="<?php echo e(url($params['route'])); ?>" class="btn btn-default">Cancelar</a>
            <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

        </div>
    </div>
</div>
<?php /**PATH /var/www/siat.antsv.gov.py/resources/views//grupos/_form.blade.php ENDPATH**/ ?>