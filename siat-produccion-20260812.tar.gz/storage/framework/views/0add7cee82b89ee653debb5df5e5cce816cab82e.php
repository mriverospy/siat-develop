<?php $__env->startSection('modalContent'); ?>
    <?php echo Form::open(['id' => 'change-pass-form', 'method' => 'POST', 'url' => $params['route'] .'/' . $params['data']['item']['id'] . '/changepass', 'class' => 'form-horizontal']); ?>

        <div class="modal-body">
            <div class="row">
                <div class="col-xs-12">
                    <p>Introduzca una nueva contraseña para <?php echo $params['data']['item']['nombres']; ?> <?php echo $params['data']['item']['apellidos']; ?>:</p>
                </div>
                <div class="col-xs-12">
                    <?php echo Form::password('password', ['class' => 'form-control', 'placeholder' => 'Nueva Contraseña']); ?>

                    <p class="help-block">La contraseña debe ser de al menos 6 caracteres, debe incluir mayúsculas, minúsculas y números. Cantidad máxima de caracteres es de 50.</p>
                </div>
                <div class="col-xs-12">
                    <div class="checkbox blue icheck">
                        <label>
                            <input type="checkbox" name="cambiar_password" value="1"> Requerir cambio de contraseña al iniciar sesión
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <?php echo Form::button('Cancelar', ['type' => 'button', 'class' => 'btn btn-default', 'data-dismiss' => 'modal']); ?>

            <?php echo Form::button('Cambiar Contraseña', ['type' => 'submit', 'class' => 'btn btn-primary']); ?>

        </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-javascript'); ?>
    <script type="text/javascript" charset="utf-8">
        $('#modalWindow').on('show.bs.modal', function (event) {
            var delRoute = "<?php echo e(url($params['route'])); ?>/" + $(event.relatedTarget).attr('data-id');
            $('#delete-form').attr("action", delRoute);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/usuarios/_change-password.blade.php ENDPATH**/ ?>