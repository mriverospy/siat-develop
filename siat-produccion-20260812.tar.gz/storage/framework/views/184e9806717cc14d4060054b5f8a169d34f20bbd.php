<?php $__env->startSection('page_filters'); ?>
    <form action="" method="GET" accept-charset="UTP-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2>FILTRAR DATOS</h2>
                <div class="panel-ctrls">
                    <div class="pull-right">
                        <button type="submit" class="btn btn-primary">Filtrar</button>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                    <div class="form-inline row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo Form::text('fecha_inicio', $params['current_filters']['fecha_inicio'], ['class' => 'form-control datepicker', 'placeholder' => 'Fecha Inicio']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::text('fecha_fin', $params['current_filters']['fecha_fin'], ['class' => 'form-control datepicker', 'placeholder' => 'Fecha Fin']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::select('accion', $params['data']['acciones'], $params['current_filters']['accion'], ['class' => 'form-control', 'placeholder' => 'Acción']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::select('usuario', $params['data']['usuarios'], $params['current_filters']['usuario'], ['class' => 'form-control', 'placeholder' => 'Usuario']); ?>

                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table_items'); ?>
    <thead>
        <tr>
            <th class="text-center">ID Usuario</th>
            <th>Usuario</th>
            <th class="text-center">Acción</th>
            <th class="text-center">Fecha Acción</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($item->usuario->id); ?></td>
            <td><?php echo e($item->usuario->nombres); ?> <?php echo e($item->usuario->apellidos); ?></td>
            <td class="text-center">
            <?php if($item->accion == 'login'): ?>
                Inicio Sesión
            <?php else: ?>
                Cierre Sesión
            <?php endif; ?>
            </td>
            <td class="text-center"><?php echo e($item->created_at); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($params['data']['items']) == 0): ?>
        <tr>
            <td colspan="4" class="h4 text-center">No se encontró ningún registro</td>
        </tr>
        <?php endif; ?>
    </tbody>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination'); ?>
    <?php echo $params['data']['items']->appends(Request::input())->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.list_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/auditoria/logins.blade.php ENDPATH**/ ?>