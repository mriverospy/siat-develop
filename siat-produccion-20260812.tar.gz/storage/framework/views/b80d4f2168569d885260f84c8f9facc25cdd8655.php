<?php $__env->startSection('layout_content'); ?>
    <script>
        var siat = {
            sedes: <?php echo $params['sedes']; ?>,
            usuarios: <?php echo $params['usuarios']; ?>

        }
    </script>
    <div class="panel <?php echo e($params['panel_color']); ?>">
        <div class="panel-heading">
            <h2><?php echo e($params['subtitle']); ?> <?php echo e($params['data']['item']->caratula); ?></h2>
        </div>
        <div class="panel-body">
            <?php echo Form::open(['route' => ['accidentes.do-authorize', $params['data']['item']->id]]); ?>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('institucion_id', 'Institución', ['class' => 'control-label']); ?>

                        <select name="institucion_id" class="select2" style="width: 100% !important">
                            <?php $__currentLoopData = $params['instituciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institucion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($institucion->id); ?>"><?php echo e($institucion->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('sede_id', 'Sede ', ['class' => 'control-label']); ?>

                        <select name="sede_id" class="select2" style="width: 100% !important">
                        </select>
                    </div>
                </div>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('usuario_id', 'Usuario', ['class' => 'control-label']); ?>

                        <select name="usuario_id" class="select2" style="width: 100% !important">
                        </select>
                    </div>
                </div>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('descripcion', 'Descripción', ['class' => 'control-label']); ?>

                        <?php echo Form::textarea('descripcion', null, ['class' => 'form-control']); ?>

                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-md-6">
                        <div class="form-horizontal">
                            <div class="form-group">
                                <?php echo Form::label('fecha_inicio', 'Fecha Inicio', ['class' => 'control-label']); ?>

                                <?php echo Form::text('fecha_inicio', null, ['class' => 'form-control datepicker']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-md-6">
                        <div class="form-horizontal">
                            <div class="form-group">
                                <?php echo Form::label('fecha_fin', 'Fecha Fin', ['class' => 'control-label']); ?>

                                <?php echo Form::text('fecha_fin', null, ['class' => 'form-control datepicker']); ?>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('campos', 'Campos', ['class' => 'control-label']); ?>

                        <select name="campos[]" multiple="multiple" class="select2" style="width: 100% !important">
                            <?php $__currentLoopData = $params['available_fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field_id => $field_text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($field_id); ?>"><?php echo e($field_text); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="panel-footer">
                    <div class="row">
                        <div class="pull-right">
                            <a href = "<?php echo e(url($params['route'])); ?>" class = 'btn btn-default'>Cancelar</a>
                            <?php echo Form::submit('Autorizar Cambios', ['class' => 'btn btn-primary']); ?>

                        </div>
                    </div>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-javascript'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer-javascript'); ?>
    <script>
        jQuery(document).ready(function($) {
            $('select[name=institucion_id]').on('change', function() {
                $('select[name=sede_id]').html('');
                $('select[name=sede_id]').val(null).trigger('change');
                $('select[name=usuario_id]').html('');
                $('select[name=usuario_id]').val(null).trigger('change');
                var selectedInstitucion = $(this).val();
                var options = '';
                $.each(siat.sedes, function(i, sede) {
                    if (sede.institucion_id == selectedInstitucion) {
                        options += '<option value="' + sede.id + '">' + sede.nombre + '</option>';
                    }
                });
                $('select[name=sede_id]').html(options);
                $('select[name=sede_id]').val(null).trigger('change');
            });

            $('select[name=sede_id]').on('change', function() {
                var selectedSede = $(this).val();
                var options = '';
                $.each(siat.usuarios, function(i, usuario) {
                    if (usuario.sede_id == selectedSede) {
                        options += '<option value="' + usuario.id + '">' + usuario.nombres + ' ' + usuario.apellidos + '</option>';
                    }
                });
                $('select[name=usuario_id]').html(options);
                $('select[name=usuario_id]').val(null).trigger('change');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/accidentes/authorize.blade.php ENDPATH**/ ?>