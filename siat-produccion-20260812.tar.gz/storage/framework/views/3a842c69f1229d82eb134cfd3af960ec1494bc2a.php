<?php $__env->startSection('page-title', 'Derivaciones'); ?>

<!-- Table List Items -->
<?php $__env->startSection('table_items'); ?>
    <thead>
        <tr>
            <th class="col-md-1 text-center" rowspan="2">ID</th>
            <th rowspan="2" class="text-center">Estado</th>
            <th rowspan="2">Accidente</th>
            <th colspan="3" class="text-center">Enviado por</th>
            <th rowspan="2">Recibido</th>
            <th rowspan="2" class="col-lg-2 col-md-2 col-sm-3 col-xs-2 text-center">Acciones</th>
        </tr>
        <tr>
            <th>Institución</th>
            <th>Sede</th>
            <th>Usuario</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($item->id); ?></td>
            <td class="text-center">
                <span class="label <?php echo e(($item->estado == 'recibido') ? 'label-success' : 'label-default'); ?>"><?php echo e(strtoupper($item->estado)); ?></span>
            </td>
            <td><?php echo e($item->accidente->caratula); ?></td>
            <td><?php echo e($item->institucion_emisor->nombre); ?></td>
            <td><?php echo e($item->sede_emisor->nombre); ?></td>
            <td><?php echo e($item->usuario_emisor->nombres); ?> <?php echo e($item->usuario_emisor->apellidos); ?></td>
            <td>
                <span data-toggle="tooltip" data-placement="top" title="recibido el <?php echo e($item->fecha_derivacion->timezone('America/Asuncion')->format('d/m/Y')); ?> a las <?php echo e($item->fecha_derivacion->timezone('America/Asuncion')->format('h:i a')); ?>">
                    <?php echo e($item->fecha_derivacion->diffForHumans()); ?>

                </span>
            </td>
            <td class="text-center">
                <?php if($item->estado != 'recibido'): ?>
                    <?php if(Auth::user()->ability('sysadmin', 'accidentes-receive')): ?>
                    <span data-toggle="tooltip" data-placement="top" title="Aceptar esta Derivación">
                        <a data-toggle="modal" data-target="#aceptar-derivacion" class="btn btn-success btn-sm" data-action="<?php echo e(route('derivaciones.update', $item->id)); ?>">
                            <i class="fa fa-check"></i>
                        </a>
                    </span>
                    <?php endif; ?>

                    <?php if(Auth::user()->ability('sysadmin', 'accidentes-receive')): ?>
                    <span data-toggle="tooltip" data-placement="top" title="Rechazar esta Derivación">
                        <a data-toggle="modal" data-target="#rechazar-derivacion" class="btn btn-danger btn-sm" data-action="<?php echo e(route('derivaciones.destroy', $item->id)); ?>">
                            <i class="fa fa-times"></i>
                        </a>
                    </span>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($params['data']['items']) == 0): ?>
            <tr><td colspan="8" class="h4 text-center">No se encontró ningún registro</td></tr>
        <?php endif; ?>
    </tbody>
<?php $__env->stopSection(); ?>

<!-- Pagination buttons -->
<?php $__env->startSection('pagination'); ?>
    <?php echo $params['data']['items']->appends(Request::input())->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('modals'); ?>
    <div class="modal fade" id="aceptar-derivacion" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar"><span aria-hidden="true">&times;</span></button>
                    <h2 class="modal-title">Aceptar Derivación</h2>
                </div>
                <div class="modal-body">
                    <p>Realmente desea aceptar la derivación seleccionada?</p>
                </div>
                <div class="modal-footer">
                    <?php echo Form::open(['id' => 'aceptar-derivacion-form', 'method' => 'PUT', 'url' => $params['route'], 'class' => 'form-inline']); ?>

                    <?php echo Form::button('Cancelar', ['type' => 'button', 'class' => 'btn btn-default','data-dismiss' => 'modal']); ?>

                    <?php echo Form::button('Aceptar Derivación', ['type' => 'submit', 'class' => 'btn btn-success']); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="rechazar-derivacion" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar"><span aria-hidden="true">&times;</span></button>
                    <h2 class="modal-title">Rechazar Derivación</h2>
                </div>
                <div class="modal-body">
                    <p>Realmente desea rechazar la derivación seleccionada?</p>
                </div>
                <div class="modal-footer">
                    <?php echo Form::open(['id' => 'rechazar-derivacion-form', 'method' => 'DELETE', 'url' => $params['route'], 'class' => 'form-inline']); ?>

                    <?php echo Form::button('Cancelar', ['type' => 'button', 'class' => 'btn btn-default','data-dismiss' => 'modal']); ?>

                    <?php echo Form::button('Rechazar Derivación', ['type' => 'submit', 'class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-javascript'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer-javascript'); ?>
    <script>
        jQuery(document).ready(function($) {
            $('#aceptar-derivacion').on('show.bs.modal', function (event) {
                $('#aceptar-derivacion-form').attr('action', $(event.relatedTarget).data('action'));
            });

            $('#rechazar-derivacion').on('show.bs.modal', function (event) {
                $('#rechazar-derivacion-form').attr('action', $(event.relatedTarget).data('action'));
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.list_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/derivaciones/received.blade.php ENDPATH**/ ?>