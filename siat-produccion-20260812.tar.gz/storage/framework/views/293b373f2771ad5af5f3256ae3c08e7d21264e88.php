<?php $__env->startSection('title_options'); ?>
    <?php if($currentUser->ability('sysadmin', $params['route_name'].'-create')): ?>
        <div class="btn-group">
            <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-fw fa-plus"></i> Agregar Pregunta <span class="caret"></span>
            </button>
            <ul class="dropdown-menu col-xs-12" role="menu">
                <span class="h5"> &nbsp; &nbsp; Tipo de Respuesta:</span>
                <li class="divider"></li>
                <li><a href="<?php echo e(url($params['route'])); ?>/create/text"><i class="fa fa-fw fa-tumblr"></i> Texto</a></li>
                <li><a href="<?php echo e(url($params['route'])); ?>/create/number"><i class="fa fa-fw fa-slack"></i> Número</a></li>
                <li><a href="<?php echo e(url($params['route'])); ?>/create/radio"><i class="fa fa-fw fa-dot-circle-o"></i> Selección Simple</a></li>
                <li><a href="<?php echo e(url($params['route'])); ?>/create/check"><i class="fa fa-fw fa-check-square-o"></i> Selección Múltiple</a></li>
                <li><a href="<?php echo e(url($params['route'])); ?>/create/date"><i class="fa fa-fw fa-calendar"></i> Fecha</a></li>
            </ul>
        </div>
    <?php endif; ?>
    <?php if($currentUser->ability('sysadmin', $params['route_name'].'-edit')): ?>
        <a href="#" id="saveOrderBtn" class="btn btn-success"><i class="fa fa-fw fa-save"></i> Guardar Orden</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('layout_content'); ?>
    <?php if(count($params['data']['items']) == 0): ?>
        <div class="col-sm-12 h4 text-center"><strong><?php echo e($params['data']['grupo']->nombre); ?></strong> no contiene preguntas, desea agregar una pregunta?</div>
        <div class="col-sm-12 text-center">
            <div class="btn-group">
                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-fw fa-plus"></i> Agregar Pregunta <span class="caret"></span>
                </button>
                <ul class="dropdown-menu col-xs-12" role="menu">
                    <span class="h5"> &nbsp; &nbsp; Tipo de Respuesta:</span>
                    <li class="divider"></li>
                    <li><a href="<?php echo e(url($params['route'])); ?>/create/text"><i class="fa fa-fw fa-tumblr"></i> Texto</a></li>
                    <li><a href="<?php echo e(url($params['route'])); ?>/create/number"><i class="fa fa-fw fa-slack"></i> Número</a></li>
                    <li><a href="<?php echo e(url($params['route'])); ?>/create/radio"><i class="fa fa-fw fa-dot-circle-o"></i> Selección Simple</a></li>
                    <li><a href="<?php echo e(url($params['route'])); ?>/create/check"><i class="fa fa-fw fa-check-square-o"></i> Selección Múltiple</a></li>
                    <li><a href="<?php echo e(url($params['route'])); ?>/create/date"><i class="fa fa-fw fa-calendar"></i> Fecha</a></li>
                </ul>
            </div>
        </div>
    <?php else: ?>
        <!--Número de Orden -->
        <div class="col-sm-1 text-center">
            <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-collapsed"><div class="panel-heading h2"><?php echo e($item->orden); ?></div></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Listado de Grupos de Preguntas -->
        <div class="col-sm-11">
            <div class="row ui-sortable" data-widget-group="group-demo">
                <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel panel-collapsed" data-widget="{'id' : '<?php echo e($item->id); ?>'}" data-pregunta-id="<?php echo e($item->id); ?>">
                        <div class="panel-heading">
                            <div class="panel-ctrls button-icon-bg" >
                                <?php if($currentUser->ability('sysadmin', $params['route_name'].'-delete')): ?>
                                <span data-toggle="tooltip" data-placement="top" title="Borrar esta Pregunta">
                                    <a data-toggle="modal" class="button-icon" data-target="#modalWindow" data-id="<?php echo e($item->id); ?>"><i class="fa fa-times"></i></a>
                                </span>
                                <?php endif; ?>
                                <?php if($currentUser->ability('sysadmin', $params['route_name'].'-edit')): ?>
                                    <a href="<?php echo e(url($params['route'], [$item->id, 'edit'])); ?>" class="button-icon" data-toggle="tooltip" data-placement="top" title="Editar esta Pregunta"><i class="fa fa-pencil"></i></a>
                                <?php endif; ?>
                            </div>
                            <h2><?php echo e($item->pregunta); ?> (ID: <?php echo e($item->id); ?>)</h2>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('modals'); ?>
    <?php echo $__env->make('layouts.confirm_modal_layout', ['modalTitle' => 'Confirmación', 'modalSize' => 'modal-sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-javascript'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer-javascript'); ?>
    <script>
        jQuery(document).ready(function($) {
            $.wijets().make();

            $('#saveOrderBtn').on('click', function (event) {
                var items = [];
                $('.ui-sortable .panel').each(function(index, element) {
                    items.push({ id: $(element).data('pregunta-id'), orden: index + 1});
                });

                $.ajax({
                    url: 'save_order',
                    type: 'POST',
                    data: {_token: <?php echo "'".Session::token()."'"; ?>, items: items},
                    success: function(data) {
                        location.reload();
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/preguntas/index.blade.php ENDPATH**/ ?>