<div class="form-horizontal">
    <div class="form-group">
        <?php if(Auth::user()->hasRole('sysadmin')): ?>
            <?php echo Form::label('institucion_id', 'Institución:', ['class'=>'control-label']); ?>

            <?php echo Form::select('institucion_id', $params['data']['patern_list'], null, ['class' => 'select2'] ); ?>

        <?php endif; ?>

        <?php echo Form::label('nombre', 'Nombre:', ['class'=>'control-label']); ?>

        <?php echo Form::text('nombre', null, ['class'=>'form-control', 'placeholder'=>'Nombre de la Sede', 'autofocus'=>'true']); ?>


        <?php echo Form::label('descripcion', 'Descripcion:', ['class'=>'control-label']); ?>

        <?php echo Form::textarea('descripcion', null, ['class'=>'form-control', 'placeholder'=>'Descripción de la Sede']); ?>

    </div>
</div>

<div class="panel-footer">
    <div class="row">
        <div class="pull-right">
            <a href = "<?php echo e(url($params['route'])); ?>" class = 'btn btn-default'>Cancelar</a>
            <?php echo Form::submit('Guardar', ['class'=>'btn btn-primary']); ?>

        </div>
    </div>
</div>
<?php /**PATH /var/www/siat.antsv.gov.py/resources/views//sedes/_form.blade.php ENDPATH**/ ?>