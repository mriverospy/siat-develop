<?php $__env->startSection('page-title', 'Grupos Master\'s'); ?>

<?php $__env->startSection('title_options'); ?>
    <?php if(Auth::user()->hasRole('sysadmin')): ?>
        <a href="#" id="saveOrderBtn" class="btn btn-success"><i class="fa fa-fw fa-save"></i> Guardar Orden</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('layout_content'); ?>

    <?php if(count($params['data']['items']) == 0): ?>
        <div class="col-sm-12 h4 text-center">No se encontró ningún Grupo Master...</div>
    <?php else: ?>
        <!--Número de Orden -->
        <div class="col-sm-1 text-center">
            <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-collapsed"><div class="panel-heading h2"><?php echo e($item->orden); ?></div></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Listado de Grupos de Preguntas -->
        <div class="col-sm-11">
            <div class="row ui-sortable" data-widget-group="group-demo">
                <?php $__currentLoopData = $params['data']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel panel-collapsed" data-widget="{'id' : '<?php echo e($item->id); ?>'}" data-grupo-id="<?php echo e($item->id); ?>">
                            <div class="panel-heading">
                                <h2><?php echo e($item->nombre); ?></h2>
                            </div>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-javascript'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer-javascript'); ?>
    <!--wijets-->
    <script type="text/javascript" charset="utf-8">
        $.wijets().make();

        $('#saveOrderBtn').on('click', function (event) {
            var items = [];
            $('.ui-sortable .panel').each(function(index, element) {
                items.push({ id: $(element).data('grupo-id'), orden: index + 1});
            });

            $.ajax({
                url: 'save_masters_order',
                type: 'POST',
                data: {
                    '_token': <?php echo "'".Session::token()."'"; ?>,
                    items: items
                },
                success: function(data){
                    location.reload();
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/grupos/order.blade.php ENDPATH**/ ?>