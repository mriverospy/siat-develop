<?php $__env->startSection('layout_content'); ?>
    <div class="panel <?php echo e($params['panel_color']); ?>">
        <div class="panel-heading">
            <h2><?php echo e($params['subtitle']); ?> <?php echo e($params['data']['item']->caratula); ?></h2>
        </div>
        <div class="panel-body">
            <?php echo Form::open(['route' => ['accidentes.send', $params['data']['item']->id]]); ?>

                <div class="form-horizontal">
                    <div class="form-group">
                        <?php echo Form::label('institucion_id', 'Siguiente Institución', ['class' => 'control-label']); ?>

                        <select name="institucion_id" class="select2" style="width: 100% !important">
                            <?php $__currentLoopData = $params['instituciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institucion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($institucion->id); ?>"><?php echo e($institucion->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="panel-footer">
                    <div class="row">
                        <div class="pull-right">
                            <a href = "<?php echo e(url($params['route'])); ?>" class = 'btn btn-default'>Cancelar</a>
                            <?php echo Form::submit('Derivar', ['class'=>'btn btn-primary']); ?>

                        </div>
                    </div>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/accidentes/send.blade.php ENDPATH**/ ?>