<!DOCTYPE html>
<html>
    <head>
        <title>Reporte de Datos</title>
        <style type="text/css">
            body {
                margin: 0;
                padding: 0;
            }

            .text-center {
                text-align: center;
            }

            .text-right {
                text-align: right;
            }

            table {
                border-collapse: collapse;
                border-spacing: 0;
            }

            thead {
                display: table-header-group;
            }

            tfoot {
                display: table-row-group;
            }

            tr {
                page-break-inside: avoid;
            }

            th {
                border: 1px solid #000;
                vertical-align: bottom;
            }

            td {
                border: 1px solid #000;
                vertical-align: top;
            }
        </style>
    </head>
    <body>
        <p class="text-center"><?php echo e($reporte->nombre); ?> &mdash; Del <?php echo e($fecha_inicio); ?> al <?php echo e($fecha_fin); ?></p>
        <table width="100%">
            <thead>
                <tr>
                    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column_key => $column_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="text-center"><?php echo e($column_name); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reporteDatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column_key => $column_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td class="<?php echo e((stristr($column_key, 'total') !== FALSE OR in_array($column_key, ['heridos', 'fallecidos', 'ilesos', 'participantes_siniestro'])) ? 'text-right' : ''); ?>">
                        <?php echo e($item->$column_key); ?>

                    </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </body>
</html>
<?php /**PATH /var/www/siat.antsv.gov.py/resources/views/reporte_datos/pdf.blade.php ENDPATH**/ ?>