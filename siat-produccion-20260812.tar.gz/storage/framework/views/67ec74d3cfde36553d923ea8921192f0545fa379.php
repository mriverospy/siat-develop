<?php $__env->startSection('layout_content'); ?>
    <div class="panel <?php echo e($params['panel_color']); ?>">
        <div class="panel-heading">
            <h2><?php echo e($params['subtitle']); ?></h2>
            <div class="text-right"><?php echo e($params['tipoNombre']); ?></div>
        </div>

        <div class="panel-body">

            <?php if(isset($params['data']['item'] )): ?>
                <!-- EDIT -->
                <?php echo Form::model($params['data']['item'], ['method'=>'PATCH','url'=>[$params['route'], $params['data']['item']->id]] ); ?>

            <?php else: ?>
                <!-- CREATE -->
                <?php echo Form::open(['url'=>$params['route']]); ?>

            <?php endif; ?>
                <div class="form-horizontal">
                    <div class="form-group">
                        <!-- TIPO -->
                        <?php echo Form::hidden('tipo', $params['tipo'] ); ?>


                        <!-- PREGUNTA -->
                        <?php echo Form::label('pregunta', 'Pregunta:', ['class' => 'control-label']); ?>

                        <?php echo Form::text('pregunta', null, ['class' => 'form-control', 'autofocus' => 'true', 'placeholder' => 'Pregunta a realizar (Ej.: Color del vehículo?)']); ?>


                        <!-- OPCIONES -->
                        <?php if($params['tipo'] == 'check' or $params['tipo'] == 'radio'): ?>
                            <?php echo Form::label('opciones', 'Opciones:', ['class' => 'control-label']); ?>

                            <?php echo Form::hidden('opciones', null, ['style' => 'width:100% !important'] ); ?>

                        <?php endif; ?>

                        <?php echo Form::label('instrucciones', 'Instrucciones:', ['class' => 'control-label']); ?>

                        <?php echo Form::text('instrucciones', null, ['class' => 'form-control', 'autofocus' => 'true', 'placeholder' => 'Instrucciones para el usuario sobre cómo contestar esta pregunta']); ?>


                        <?php if($params['tipo'] == 'check' or $params['tipo'] == 'radio'): ?>
                            <?php echo Form::label('mostrar_selector', 'Mostrar Otro?', ['class' => 'control-label']); ?>

                            <div class="radio">
                                <label>
                                    <?php echo Form::radio('mostrar_otro', 1); ?> Sí
                                </label>
                                <label>
                                    <?php echo Form::radio('mostrar_otro', 0); ?> No
                                </label>
                            </div>
                            <p class="help-block">Puede incluir una opción adicional "Otro" para que el usuario ingrese una opción no disponible en la lista de opciones.</p>

                            <?php echo Form::label('titulo_otro', 'Título "Otro":', ['class' => 'control-label']); ?>

                            <?php echo Form::text('titulo_otro', null, ['class' => 'form-control', 'autofocus' => 'true', 'placeholder' => 'Por defecto se muestra "Otro", puede personalizar el título aquí']); ?>

                            <p class="help-block">Puede definir un título personalizado, por defecto, se muestra "Otro" en el Formulario de Carga.</p>
                        <?php endif; ?>

                        <?php if($params['tipo'] == 'radio'): ?>
                            <?php echo Form::label('mostrar_selector', 'Mostrar como Selector?', ['class' => 'control-label']); ?>

                            <div class="radio">
                                <label>
                                    <?php echo Form::radio('mostrar_selector', 1); ?> Sí
                                </label>
                                <label>
                                    <?php echo Form::radio('mostrar_selector', 0); ?> No
                                </label>
                            </div>
                            <p class="help-block">Mostrar la pregunta como un selector con buscador. Recomendado si la pregunta tiene muchas opciones de respuesta.</p>
                        <?php endif; ?>



                            <!-- Nuevo campo para "Obligatorio" -->

                            <?php echo Form::label('obligatorio', 'Obligatorio?', ['class' => 'control-label']); ?>

                            <div class="radio">
                                <label>
                                    <?php echo Form::radio('obligatorio', 1); ?> Sí
                                </label>
                                <label>
                                    <?php echo Form::radio('obligatorio', 0); ?> No
                                </label>
                            </div>
                            <p class="help-block">Hacer que esta pregunta sea obligatoria para el usuario.</p>
                    </div>
                </div>

                <div class="panel-footer">
                    <div class="row">
                        <div class="pull-right">
                            <a href="<?php echo e(url($params['route'])); ?>" class="btn btn-default">Cancelar</a>
                            <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

                        </div>
                    </div>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-javascript'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer-javascript'); ?>
    <script type="text/javascript" charset="utf-8">
        jQuery(document).ready(function($) {
            $('#opciones').select2({
                width: '100%',
                separator: '|',
                placeholder: 'Opciones de respuesta (presione ENTER para establecer cada una)',
                tags: ['Otro']
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/preguntas/_form.blade.php ENDPATH**/ ?>