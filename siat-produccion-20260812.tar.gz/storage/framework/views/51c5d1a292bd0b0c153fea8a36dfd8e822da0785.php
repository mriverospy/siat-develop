<?php $__env->startSection('page-title', 'Editar Usuario'); ?>

<?php $__env->startSection('layout_content'); ?>
    <div class="panel panel-midnightblue">
        <div class="panel-heading">
            <h2><?php echo e($params['subtitle']); ?></h2>
        </div>

        <div class="panel-body">
            <?php echo Form::model($params['data']['item'], ['method' => 'PATCH', 'url' => [$params['route'], $params['data']['item']->id]] ); ?>

                <?php echo $__env->make('usuarios._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<!-- Include Modal Change Password -->
<?php echo $__env->make('usuarios._change-password', ['modalTitle' => 'Cambiar Contraseña', 'modalSize' => 'modal-sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/siat.antsv.gov.py/resources/views/usuarios/edit.blade.php ENDPATH**/ ?>