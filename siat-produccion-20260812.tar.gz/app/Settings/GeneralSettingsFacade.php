<?php

namespace App\Settings;

use Illuminate\Support\Facades\Facade;

class GeneralSettingsFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'settings';
    }
}
